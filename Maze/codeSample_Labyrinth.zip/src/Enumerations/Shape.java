package Enumerations;

/**
 * Data representation of the shape of the Tile.
 */
public enum Shape {
  CORNER, CROSS, T, LINE
}
