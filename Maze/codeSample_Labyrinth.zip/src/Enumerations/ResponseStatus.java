package Enumerations;

public enum ResponseStatus {
    OK, ERROR
}
